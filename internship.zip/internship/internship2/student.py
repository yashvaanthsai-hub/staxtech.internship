import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score

# Sample dataset
data = {
    'CGPA': [8.5, 6.2, 7.8, 5.9, 9.1, 6.8],
    'Attendance': [90, 65, 80, 60, 95, 70],
    'Projects': [3, 1, 2, 1, 4, 2],
    'Success': [1, 0, 1, 0, 1, 0]  # 1 = Successful, 0 = Not
}

df = pd.DataFrame(data)

X = df[['CGPA', 'Attendance', 'Projects']]
y = df['Success']

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.3, random_state=42
)

model = LogisticRegression()
model.fit(X_train, y_train)

predictions = model.predict(X_test)
accuracy = accuracy_score(y_test, predictions)

print("Accuracy:", accuracy)

# Predict for new student
new_student = [[8.2, 85, 3]]
result = model.predict(new_student)
print("Prediction (1=Success, 0=Fail):", result[0])
